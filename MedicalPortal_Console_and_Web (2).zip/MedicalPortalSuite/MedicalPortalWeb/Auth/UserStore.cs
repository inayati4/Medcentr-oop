using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace MedicalPortalWeb.Auth;

public enum UserRole { Admin, Doctor, Patient }

public enum AccountStatus { Active, Pending, Blocked }

public class UserAccount
{
    public int Id { get; init; }
    public string Login { get; init; } = "";
    public byte[] Salt { get; init; } = Array.Empty<byte>();
    public byte[] PasswordHash { get; init; } = Array.Empty<byte>();
    public UserRole Role { get; init; }
    public AccountStatus Status { get; set; }
    /// <summary>Id пациента или врача, к которому привязан аккаунт (у администратора — null).</summary>
    public int? LinkedId { get; init; }
    public string DisplayName { get; init; } = "";
    public DateTime CreatedAt { get; init; } = DateTime.Now;
    public int FailedAttempts { get; set; }
    public DateTime? LockedUntil { get; set; }
}

/// <summary>Хранилище учётных записей (в памяти). Пароли хранятся только в виде PBKDF2-хеша с солью.</summary>
public class UserStore
{
    private const int Iterations = 120_000;
    private static readonly Regex LoginRegex = new("^[A-Za-z0-9_.-]{3,32}$", RegexOptions.Compiled);
    private static readonly byte[] DummySalt = RandomNumberGenerator.GetBytes(16);

    private readonly List<UserAccount> _users = new();
    private int _nextId = 1;

    public IReadOnlyList<UserAccount> All => _users;

    private static byte[] Hash(string password, byte[] salt) =>
        Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);

    public UserAccount? Find(int id) => _users.FirstOrDefault(u => u.Id == id);

    public UserAccount? FindByLogin(string login) =>
        _users.FirstOrDefault(u => string.Equals(u.Login, login.Trim(), StringComparison.OrdinalIgnoreCase));

    public UserAccount? FindByLinked(UserRole role, int linkedId) =>
        _users.FirstOrDefault(u => u.Role == role && u.LinkedId == linkedId);

    public void ValidateCredentials(string? login, string? password)
    {
        if (string.IsNullOrWhiteSpace(login) || !LoginRegex.IsMatch(login.Trim()))
            throw new ArgumentException("Логин: 3–32 символа, только латинские буквы, цифры, «_», «.» и «-».");
        if (FindByLogin(login) != null)
            throw new ArgumentException("Этот логин уже занят.");
        if (password is null || password.Length < 8 || password.Length > 128 ||
            !password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            throw new ArgumentException("Пароль: не менее 8 символов, должен содержать буквы и цифры.");
    }

    public UserAccount Create(string login, string password, UserRole role, AccountStatus status,
                              int? linkedId, string displayName)
    {
        ValidateCredentials(login, password);
        var salt = RandomNumberGenerator.GetBytes(16);
        var user = new UserAccount
        {
            Id = _nextId++,
            Login = login.Trim(),
            Salt = salt,
            PasswordHash = Hash(password, salt),
            Role = role,
            Status = status,
            LinkedId = linkedId,
            DisplayName = displayName
        };
        _users.Add(user);
        return user;
    }

    public UserAccount? Authenticate(string? login, string? password, out string? error)
    {
        error = "Неверный логин или пароль.";
        if (string.IsNullOrWhiteSpace(login) || password is null || password.Length > 128) return null;

        var user = FindByLogin(login);
        if (user == null)
        {
            Hash(password, DummySalt);   // чтобы время ответа не выдавало, существует ли логин
            return null;
        }

        if (user.LockedUntil is DateTime until && until > DateTime.Now)
        {
            error = "Слишком много неудачных попыток входа. Повторите через несколько минут.";
            return null;
        }

        if (!CryptographicOperations.FixedTimeEquals(Hash(password, user.Salt), user.PasswordHash))
        {
            user.FailedAttempts++;
            if (user.FailedAttempts >= 5)
            {
                user.LockedUntil = DateTime.Now.AddMinutes(5);
                user.FailedAttempts = 0;
            }
            return null;
        }

        user.FailedAttempts = 0;
        user.LockedUntil = null;

        if (user.Status == AccountStatus.Pending)
        {
            error = "Аккаунт врача ожидает подтверждения администратором.";
            return null;
        }
        if (user.Status == AccountStatus.Blocked)
        {
            error = "Аккаунт заблокирован. Обратитесь к администратору.";
            return null;
        }

        error = null;
        return user;
    }
}
