using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using MedicalPortalApp.Models;
using MedicalPortalApp.Services;
using MedicalPortalWeb.Auth;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://localhost:5080");

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "medportal.auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
        options.Events.OnRedirectToLogin = ctx => { ctx.Response.StatusCode = 401; return Task.CompletedTask; };
        options.Events.OnRedirectToAccessDenied = ctx => { ctx.Response.StatusCode = 403; return Task.CompletedTask; };
    });

var app = builder.Build();

var portal = new MedicalPortal();
portal.SeedDemoData();
var users = new UserStore();
var gate = new object();   // данные в памяти — запросы выполняем по одному

// Код для регистрации администратора: из настроек (AdminInviteCode) или случайный, печатается в консоль.
string inviteCode = builder.Configuration["AdminInviteCode"] ?? "";
if (string.IsNullOrWhiteSpace(inviteCode))
{
    inviteCode = Convert.ToHexString(RandomNumberGenerator.GetBytes(6));
    Console.WriteLine($"Код регистрации администратора (действует до перезапуска): {inviteCode}");
}
int adminCodeFailures = 0;
DateTime adminCodeLockedUntil = DateTime.MinValue;

app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
    if (ctx.Request.Path.StartsWithSegments("/api")) ctx.Response.Headers["Cache-Control"] = "no-store";
    await next();
});
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthentication();

var AdminOnly = new[] { UserRole.Admin };
var Staff = new[] { UserRole.Admin, UserRole.Doctor };
var AdminOrPatient = new[] { UserRole.Admin, UserRole.Patient };
var Everyone = new[] { UserRole.Admin, UserRole.Doctor, UserRole.Patient };

// ---------- Вспомогательные функции ----------

IResult Bad(string message) => Results.BadRequest(new { error = message });
IResult Missing(string message) => Results.NotFound(new { error = message });
IResult Denied() => Results.Json(new { error = "Недостаточно прав." }, statusCode: 403);

IResult Safe(Func<IResult> action)
{
    try { lock (gate) { return action(); } }
    catch (ArgumentException ex) { return Bad(ex.Message); }
    catch (InvalidOperationException ex) { return Bad(ex.Message); }
}

UserAccount? CurrentUser(HttpContext c)
{
    if (!int.TryParse(c.User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)) return null;
    var user = users.Find(id);
    return user is { Status: AccountStatus.Active } ? user : null;   // заблокированных выкидываем сразу
}

/// <summary>Проверяет вход и роль, затем выполняет действие под блокировкой.</summary>
IResult Secure(HttpContext c, UserRole[] roles, Func<UserAccount, IResult> action)
{
    try
    {
        lock (gate)
        {
            var user = CurrentUser(c);
            if (user == null) return Results.Json(new { error = "Требуется вход в систему." }, statusCode: 401);
            if (!roles.Contains(user.Role)) return Denied();
            return action(user);
        }
    }
    catch (ArgumentException ex) { return Bad(ex.Message); }
    catch (InvalidOperationException ex) { return Bad(ex.Message); }
}

async Task SignIn(HttpContext c, UserAccount user)
{
    var claims = new List<Claim>
    {
        new(ClaimTypes.NameIdentifier, user.Id.ToString()),
        new(ClaimTypes.Name, user.Login),
        new(ClaimTypes.Role, user.Role.ToString())
    };
    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    await c.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
}

static object MeInfo(UserAccount u) => new
{
    authenticated = true, id = u.Id, login = u.Login, role = u.Role.ToString(),
    displayName = u.DisplayName, linkedId = u.LinkedId
};

Doctor? DoctorOf(UserAccount u) => u.Role == UserRole.Doctor && u.LinkedId is int id ? portal.FindDoctorById(id) : null;

/// <summary>Админ видит всех; врач — только пациентов со своими записями; пациент — только себя.</summary>
bool CanSeePatient(UserAccount u, Patient p) => u.Role switch
{
    UserRole.Admin => true,
    UserRole.Doctor => DoctorOf(u) is { } d &&
                       d.Appointments.Any(a => a.Patient == p && a.Status != AppointmentStatus.Cancelled),
    UserRole.Patient => u.LinkedId == p.PatientId,
    _ => false
};

bool OwnsAppointment(UserAccount u, Appointment a) => u.Role switch
{
    UserRole.Admin => true,
    UserRole.Doctor => a.Doctor.DoctorId == u.LinkedId,
    UserRole.Patient => a.Patient.PatientId == u.LinkedId,
    _ => false
};

/// <summary>Врач с неподтверждённым или заблокированным аккаунтом недоступен для записи.</summary>
bool IsBookable(Doctor d)
{
    var account = users.FindByLinked(UserRole.Doctor, d.DoctorId);
    return account == null || account.Status == AccountStatus.Active;
}

static object ToPatient(Patient p) => new
{
    id = p.PatientId, fullName = p.FullName, birthDate = p.BirthDate.ToString("yyyy-MM-dd"),
    age = p.GetAge(), phone = p.PhoneNumber, email = p.Email, address = p.Address,
    appointments = p.Appointments.Count
};

static object ToDoctor(Doctor d) => new
{
    id = d.DoctorId, fullName = d.FullName, specialization = d.Specialization,
    experience = d.Experience, cabinet = d.CabinetNumber, salary = d.Salary,
    toPay = d.CalculateSalary(), department = d.Department?.DepartmentName
};

static object ToDoctorPublic(Doctor d) => new
{
    id = d.DoctorId, fullName = d.FullName, specialization = d.Specialization,
    experience = d.Experience, cabinet = d.CabinetNumber, department = d.Department?.DepartmentName
};

static object ToAppointment(Appointment a) => new
{
    id = a.AppointmentId, patientId = a.Patient.PatientId, patientName = a.Patient.FullName,
    doctorId = a.Doctor.DoctorId, doctorName = a.Doctor.FullName, specialization = a.Doctor.Specialization,
    date = a.AppointmentDate.ToString("yyyy-MM-dd"), time = a.AppointmentTime.ToString(@"hh\:mm"),
    status = a.Status.ToString(), statusText = a.Status.ToRussian()
};

static object ToPayment(Payment p) => new
{
    id = p.PaymentId, patientName = p.Patient.FullName, amount = p.Amount, description = p.Description,
    status = p.PaymentStatus.ToString(), statusText = p.PaymentStatus.ToRussian(),
    date = p.PaymentDate?.ToString("dd.MM.yyyy HH:mm")
};

static TimeSpan ParseTime(string? value)
{
    if (!TimeSpan.TryParse(value, out var time))
        throw new ArgumentException("Неверный формат времени.");
    return time;
}

// =====================================================================
//                       Аутентификация и регистрация
// =====================================================================

app.MapGet("/api/auth/me", (HttpContext c) => Safe(() =>
{
    var user = CurrentUser(c);
    return Results.Ok(user == null ? new { authenticated = false } : MeInfo(user));
}));

app.MapPost("/api/auth/login", async (HttpContext c, LoginDto d) =>
{
    UserAccount? user;
    string? error;
    lock (gate) { user = users.Authenticate(d.Login, d.Password, out error); }
    if (user == null) return Results.Json(new { error }, statusCode: 401);
    await SignIn(c, user);
    return Results.Ok(MeInfo(user));
});

app.MapPost("/api/auth/logout", async (HttpContext c) =>
{
    await c.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Ok(new { ok = true });
});

app.MapPost("/api/auth/register/patient", async (HttpContext c, RegisterPatientDto d) =>
{
    UserAccount? user = null;
    IResult? failure = null;
    lock (gate)
    {
        try
        {
            users.ValidateCredentials(d.Login, d.Password);   // сначала логин и пароль, чтобы не плодить «сирот»
            var patient = portal.AddPatient(d.FullName, d.BirthDate, d.Phone, d.Email, d.Address);
            user = users.Create(d.Login!, d.Password!, UserRole.Patient, AccountStatus.Active,
                                patient.PatientId, patient.FullName);
        }
        catch (ArgumentException ex) { failure = Bad(ex.Message); }
    }
    if (user == null) return failure!;
    await SignIn(c, user);
    return Results.Ok(MeInfo(user));
});

app.MapPost("/api/auth/register/doctor", (RegisterDoctorDto d) => Safe(() =>
{
    users.ValidateCredentials(d.Login, d.Password);
    // Оклад назначает администратор, поэтому сначала 0.
    var doctor = portal.AddDoctor(d.FullName, d.BirthDate, d.Specialization, d.Experience, d.Cabinet, 0m);
    if (d.DepartmentId is int depId && depId > 0)
        portal.FindDepartmentById(depId)?.AddDoctor(doctor);
    users.Create(d.Login!, d.Password!, UserRole.Doctor, AccountStatus.Pending, doctor.DoctorId, doctor.FullName);
    return Results.Ok(new { pending = true, message = "Заявка отправлена. Войти можно после подтверждения администратором." });
}));

app.MapPost("/api/auth/register/admin", async (HttpContext c, RegisterAdminDto d) =>
{
    UserAccount? user = null;
    IResult? failure = null;
    lock (gate)
    {
        try
        {
            if (DateTime.Now < adminCodeLockedUntil)
                throw new InvalidOperationException("Регистрация администратора временно заблокирована из-за неверных кодов.");

            var supplied = Encoding.UTF8.GetBytes((d.InviteCode ?? "").Trim());
            var expected = Encoding.UTF8.GetBytes(inviteCode);
            if (!CryptographicOperations.FixedTimeEquals(supplied, expected))
            {
                if (++adminCodeFailures >= 10)
                {
                    adminCodeLockedUntil = DateTime.Now.AddMinutes(10);
                    adminCodeFailures = 0;
                }
                throw new ArgumentException("Неверный код администратора.");
            }
            adminCodeFailures = 0;

            if (string.IsNullOrWhiteSpace(d.FullName)) throw new ArgumentException("ФИО не может быть пустым.");
            users.ValidateCredentials(d.Login, d.Password);
            user = users.Create(d.Login!, d.Password!, UserRole.Admin, AccountStatus.Active, null, d.FullName.Trim());
        }
        catch (ArgumentException ex) { failure = Bad(ex.Message); }
        catch (InvalidOperationException ex) { failure = Bad(ex.Message); }
    }
    if (user == null) return failure!;
    await SignIn(c, user);
    return Results.Ok(MeInfo(user));
});

// =====================================================================
//                              Справочники
// =====================================================================

app.MapGet("/api/departments", () => Safe(() => Results.Ok(portal.Departments.Select(d => new
{
    id = d.DepartmentId, name = d.DepartmentName, floor = d.Floor, phone = d.PhoneNumber,
    head = d.HeadDoctor?.FullName, doctors = d.Doctors.Select(x => x.FullName).ToList()
}).ToList())));

app.MapGet("/api/services", (HttpContext c) => Secure(c, Everyone, _ => Results.Ok(portal.Services.Select(s => new
{
    id = s.ServiceId, name = s.ServiceName, description = s.Description,
    price = s.Price, duration = s.Duration
}).ToList())));

app.MapGet("/api/stats", (HttpContext c) => Secure(c, AdminOnly, _ => Results.Ok(portal.GetStatistics())));

// =====================================================================
//                              Администратор
// =====================================================================

app.MapGet("/api/admin/users", (HttpContext c) => Secure(c, AdminOnly, _ => Results.Ok(users.All.Select(a => new
{
    id = a.Id, login = a.Login, role = a.Role.ToString(), displayName = a.DisplayName,
    status = a.Status.ToString(), createdAt = a.CreatedAt.ToString("dd.MM.yyyy HH:mm")
}).ToList())));

app.MapPost("/api/admin/users/{id:int}/{action}", (HttpContext c, int id, string action) => Secure(c, AdminOnly, me =>
{
    var target = users.Find(id);
    if (target == null) return Missing("Пользователь не найден.");

    switch (action)
    {
        case "approve":
            if (target.Status != AccountStatus.Pending) return Bad("Подтверждать нужно только ожидающие аккаунты.");
            target.Status = AccountStatus.Active;
            break;
        case "block":
            if (target.Id == me.Id) return Bad("Нельзя заблокировать собственный аккаунт.");
            target.Status = AccountStatus.Blocked;
            break;
        case "unblock":
            if (target.Status != AccountStatus.Blocked) return Bad("Аккаунт не заблокирован.");
            target.Status = AccountStatus.Active;
            break;
        default:
            return Bad("Неизвестное действие.");
    }
    return Results.Ok(new { id = target.Id, status = target.Status.ToString() });
}));

app.MapPost("/api/doctors/{id:int}/salary", (HttpContext c, int id, SalaryDto d) => Secure(c, AdminOnly, _ =>
{
    var doctor = portal.FindDoctorById(id);
    if (doctor == null) return Missing("Врач не найден.");
    doctor.Salary = d.Salary;
    return Results.Ok(ToDoctor(doctor));
}));

// =====================================================================
//                                Врачи
// =====================================================================

app.MapGet("/api/doctors", (HttpContext c) => Secure(c, Everyone, u =>
    u.Role == UserRole.Admin
        ? Results.Ok(portal.Doctors.Select(ToDoctor).ToList())
        : Results.Ok(portal.Doctors.Where(IsBookable).Select(ToDoctorPublic).ToList())));

app.MapPost("/api/doctors", (HttpContext c, DoctorDto d) => Secure(c, AdminOnly, _ =>
{
    var doctor = portal.AddDoctor(d.FullName, d.BirthDate, d.Specialization, d.Experience, d.Cabinet, d.Salary);
    if (d.DepartmentId is int depId && depId > 0)
        portal.FindDepartmentById(depId)?.AddDoctor(doctor);
    return Results.Ok(ToDoctor(doctor));
}));

app.MapGet("/api/me/doctor", (HttpContext c) => Secure(c, new[] { UserRole.Doctor }, u =>
{
    var doctor = DoctorOf(u);
    return doctor == null ? Missing("Профиль врача не найден.") : Results.Ok(ToDoctor(doctor));
}));

app.MapGet("/api/doctors/{id:int}/schedule", (HttpContext c, int id, DateTime date) => Secure(c, Everyone, u =>
{
    var doctor = portal.FindDoctorById(id);
    if (doctor == null || (u.Role != UserRole.Admin && !IsBookable(doctor)))
        return Missing("Врач не найден.");

    var free = doctor.GetFreeSlots(date)
                     .Where(t => date.Date + t > DateTime.Now)
                     .Select(t => t.ToString(@"hh\:mm")).ToList();

    // Чужие записи видит только администратор и сам врач.
    bool seesBooked = u.Role == UserRole.Admin || (u.Role == UserRole.Doctor && u.LinkedId == doctor.DoctorId);
    var booked = seesBooked
        ? portal.GetDoctorSchedule(doctor, date).Select(ToAppointment).ToList()
        : new List<object>();
    return Results.Ok(new { free, booked });
}));

// =====================================================================
//                               Пациенты
// =====================================================================

app.MapGet("/api/patients", (HttpContext c, string? mode, string? q) => Secure(c, Staff, u =>
{
    IEnumerable<Patient> list = portal.Patients;
    if (!string.IsNullOrWhiteSpace(q))
    {
        if (mode == "id")
        {
            var found = int.TryParse(q, out var id) ? portal.FindPatientById(id) : null;
            list = found == null ? new List<Patient>() : new List<Patient> { found };
        }
        else if (mode == "phone") list = portal.SearchPatientsByPhone(q);
        else list = portal.SearchPatientsByName(q);
    }
    return Results.Ok(list.Where(p => CanSeePatient(u, p)).Select(ToPatient).ToList());
}));

app.MapPost("/api/patients", (HttpContext c, PatientDto d) => Secure(c, AdminOnly, _ =>
{
    var p = portal.AddPatient(d.FullName, d.BirthDate, d.Phone, d.Email, d.Address);
    return Results.Ok(ToPatient(p));
}));

app.MapGet("/api/patients/{id:int}", (HttpContext c, int id) => Secure(c, Everyone, u =>
{
    var p = portal.FindPatientById(id);
    if (p == null) return u.Role == UserRole.Admin ? Missing($"Пациент с ID {id} не найден.") : Denied();
    if (!CanSeePatient(u, p)) return Denied();

    return Results.Ok(new
    {
        patient = ToPatient(p),
        diagnosis = p.Record.Diagnosis,
        history = p.Record.MedicalHistory,
        tests = p.Tests.Select(t => new
        {
            id = t.TestId, name = t.TestName, date = t.TestDate.ToString("yyyy-MM-dd"), result = t.Result
        }).ToList(),
        prescriptions = p.Prescriptions.Select(x => new
        {
            id = x.PrescriptionId, doctor = x.Doctor.FullName, medication = x.MedicationName,
            dosage = x.Dosage, days = x.Duration
        }).ToList()
    });
}));

app.MapPost("/api/me/profile", (HttpContext c, ProfileDto d) => Secure(c, new[] { UserRole.Patient }, u =>
{
    var patient = u.LinkedId is int id ? portal.FindPatientById(id) : null;
    if (patient == null) return Missing("Профиль пациента не найден.");
    patient.UpdateProfile(d.Phone, d.Email, d.Address);
    return Results.Ok(ToPatient(patient));
}));

app.MapPost("/api/patients/{id:int}/diagnosis", (HttpContext c, int id, DiagnosisDto d) => Secure(c, Staff, u =>
{
    var p = portal.FindPatientById(id);
    if (p == null || !CanSeePatient(u, p)) return Denied();
    p.Record.AddDiagnosis(d.Diagnosis);
    return Results.Ok(new { diagnosis = p.Record.Diagnosis });
}));

app.MapPost("/api/tests", (HttpContext c, TestDto d) => Secure(c, Staff, u =>
{
    var p = portal.FindPatientById(d.PatientId);
    if (p == null || !CanSeePatient(u, p)) return Denied();
    var test = portal.AddMedicalTest(p, d.TestName, d.TestDate ?? DateTime.Today, d.Result);
    return Results.Ok(new { id = test.TestId });
}));

app.MapPost("/api/prescriptions", (HttpContext c, PrescriptionDto d) => Secure(c, Staff, u =>
{
    var p = portal.FindPatientById(d.PatientId);
    if (p == null || !CanSeePatient(u, p)) return Denied();

    // Врач выписывает назначение только от своего имени.
    var doctor = u.Role == UserRole.Doctor ? DoctorOf(u) : portal.FindDoctorById(d.DoctorId);
    if (doctor == null) return Missing("Врач не найден.");

    var pr = portal.CreatePrescription(p, doctor, d.Medication, d.Dosage, d.Days);
    return Results.Ok(new { id = pr.PrescriptionId });
}));

// =====================================================================
//                           Записи на приём
// =====================================================================

app.MapGet("/api/appointments", (HttpContext c) => Secure(c, Everyone, u => Results.Ok(
    portal.Appointments.Where(a => OwnsAppointment(u, a))
                       .OrderBy(a => a.StartTime).Select(ToAppointment).ToList())));

app.MapPost("/api/appointments", (HttpContext c, AppointmentDto d) => Secure(c, AdminOrPatient, u =>
{
    // Пациент записывает только себя; администратор — любого.
    int patientId = u.Role == UserRole.Patient ? (u.LinkedId ?? -1) : d.PatientId;
    var patient = portal.FindPatientById(patientId);
    var doctor = portal.FindDoctorById(d.DoctorId);
    if (patient == null) return Missing("Пациент не найден.");
    if (doctor == null || (u.Role != UserRole.Admin && !IsBookable(doctor))) return Missing("Врач не найден.");

    var appointment = portal.TryBookAppointment(patient, doctor, d.Date, ParseTime(d.Time), out var error);
    return appointment == null ? Bad(error ?? "Не удалось создать запись.") : Results.Ok(ToAppointment(appointment));
}));

app.MapPost("/api/appointments/{id:int}/{action}", (HttpContext c, int id, string action) => Secure(c, Everyone, u =>
{
    var a = portal.FindAppointmentById(id);
    if (a == null || !OwnsAppointment(u, a))
        return u.Role == UserRole.Admin ? Missing($"Запись с ID {id} не найдена.") : Denied();

    // Пациент может только отменять свои записи.
    if (u.Role == UserRole.Patient && action != "cancel") return Denied();

    string? error = null;
    bool ok;
    if (action == "confirm") ok = a.TryConfirm(out error);
    else if (action == "cancel") ok = a.TryCancel(out error);
    else if (action == "complete") ok = a.TryComplete(out error);
    else return Bad("Неизвестное действие.");

    return ok ? Results.Ok(ToAppointment(a)) : Bad(error ?? "Операция невозможна.");
}));

// =====================================================================
//                                Оплата
// =====================================================================

app.MapGet("/api/payments", (HttpContext c) => Secure(c, AdminOrPatient, u => Results.Ok(
    portal.Payments.Where(p => u.Role == UserRole.Admin || p.Patient.PatientId == u.LinkedId)
                   .OrderByDescending(p => p.PaymentId).Select(ToPayment).ToList())));

app.MapPost("/api/payments", (HttpContext c, PaymentDto d) => Secure(c, AdminOrPatient, u =>
{
    int patientId = u.Role == UserRole.Patient ? (u.LinkedId ?? -1) : d.PatientId;
    var patient = portal.FindPatientById(patientId);
    var service = portal.FindServiceById(d.ServiceId);
    if (patient == null) return Missing("Пациент не найден.");
    if (service == null) return Missing("Услуга не найдена.");
    return Results.Ok(ToPayment(portal.PayForService(patient, service, d.Quantity)));
}));

app.MapPost("/api/payments/{id:int}/refund", (HttpContext c, int id) => Secure(c, AdminOnly, _ =>
{
    var payment = portal.FindPaymentById(id);
    if (payment == null) return Missing($"Платёж с ID {id} не найден.");
    if (payment.PaymentStatus != PaymentStatus.Paid) return Bad("Вернуть можно только оплаченный платёж.");
    payment.RefundPayment();
    return Results.Ok(ToPayment(payment));
}));

Console.WriteLine("Медицинский портал: http://localhost:5080");
app.Run();

// ---------- DTO запросов ----------

record LoginDto(string? Login, string? Password);
record RegisterPatientDto(string? Login, string? Password, string FullName, DateTime BirthDate,
                          string Phone, string Email, string Address);
record RegisterDoctorDto(string? Login, string? Password, string FullName, DateTime BirthDate,
                         string Specialization, int Experience, int Cabinet, int? DepartmentId);
record RegisterAdminDto(string? Login, string? Password, string FullName, string? InviteCode);
record ProfileDto(string Phone, string Email, string Address);
record SalaryDto(decimal Salary);
record PatientDto(string FullName, DateTime BirthDate, string Phone, string Email, string Address);
record DoctorDto(string FullName, DateTime BirthDate, string Specialization, int Experience, int Cabinet,
                 decimal Salary, int? DepartmentId);
record AppointmentDto(int PatientId, int DoctorId, DateTime Date, string Time);
record PaymentDto(int PatientId, int ServiceId, int Quantity);
record DiagnosisDto(string Diagnosis);
record TestDto(int PatientId, string TestName, DateTime? TestDate, string? Result);
record PrescriptionDto(int PatientId, int DoctorId, string Medication, string Dosage, int Days);
