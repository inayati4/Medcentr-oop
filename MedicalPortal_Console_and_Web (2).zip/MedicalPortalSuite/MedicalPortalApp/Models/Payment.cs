namespace MedicalPortalApp.Models;

public class Payment : IPayable
{
    public Payment(int paymentId, Patient patient, decimal amount, string description = "")
    {
        ArgumentNullException.ThrowIfNull(patient);
        if (amount <= 0)
            throw new ArgumentException("Сумма платежа должна быть больше нуля.");

        PaymentId = paymentId;
        Patient = patient;
        Amount = amount;
        Description = description;
        PaymentStatus = PaymentStatus.Pending;
    }

    public int PaymentId { get; }
    public Patient Patient { get; }
    public decimal Amount { get; }
    public string Description { get; }
    public DateTime? PaymentDate { get; private set; }
    public PaymentStatus PaymentStatus { get; private set; }

    public decimal CalculatePayment() => Amount;

    public bool MakePayment()
    {
        if (PaymentStatus != PaymentStatus.Pending)
        {
            Console.WriteLine($"Платёж уже обработан (статус: {this.PaymentStatus.ToRussian()}).");
            return false;
        }
        PaymentStatus = PaymentStatus.Paid;
        PaymentDate = DateTime.Now;
        return true;
    }

    public bool RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid)
        {
            Console.WriteLine("Вернуть можно только оплаченный платёж.");
            return false;
        }
        PaymentStatus = PaymentStatus.Refunded;
        return true;
    }

    public void DisplayPayment()
    {
        Console.WriteLine($"[Платёж #{PaymentId}] {Patient.FullName} | {Amount:N2} тг | {Description}");
        Console.WriteLine($"   Статус: {this.PaymentStatus.ToRussian()}" +
                          (PaymentDate.HasValue ? $" | Дата: {PaymentDate:dd.MM.yyyy HH:mm}" : ""));
    }
}
