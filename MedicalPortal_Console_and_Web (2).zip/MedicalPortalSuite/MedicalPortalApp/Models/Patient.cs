namespace MedicalPortalApp.Models;

public class Patient : Person
{
    private string _phoneNumber = string.Empty;
    private string _email = string.Empty;
    private string _address = string.Empty;

    private readonly List<Appointment> _appointments = new();
    private readonly List<MedicalTest> _tests = new();
    private readonly List<Prescription> _prescriptions = new();

    public Patient(int patientId, string fullName, DateTime birthDate,
                   string phoneNumber, string email, string address)
        : base(patientId, fullName, birthDate)
    {
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;

        // Композиция (задача 14): медицинская карта создаётся вместе с пациентом
        // и не существует отдельно от него.
        Record = new MedicalRecord(patientId, this);
    }

    public int PatientId => Id;

    public string PhoneNumber
    {
        get => _phoneNumber;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Номер телефона не может быть пустым.");
            if (value.Count(char.IsDigit) < 7)
                throw new ArgumentException("Номер телефона должен содержать не менее 7 цифр.");
            _phoneNumber = value.Trim();
        }
    }

    public string Email
    {
        get => _email;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("E-mail не может быть пустым.");
            var v = value.Trim();
            if (!v.Contains('@') || v.StartsWith('@') || v.EndsWith('@'))
                throw new ArgumentException("E-mail указан неверно.");
            _email = v;
        }
    }

    public string Address
    {
        get => _address;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Адрес не может быть пустым.");
            _address = value.Trim();
        }
    }

    public MedicalRecord Record { get; }
    public IReadOnlyList<Appointment> Appointments => _appointments;      // 1 -> 0..*
    public IReadOnlyList<MedicalTest> Tests => _tests;
    public IReadOnlyList<Prescription> Prescriptions => _prescriptions;

    internal void AddAppointment(Appointment appointment) => _appointments.Add(appointment);
    internal void AddTest(MedicalTest test) => _tests.Add(test);
    internal void AddPrescription(Prescription prescription) => _prescriptions.Add(prescription);

    /// <summary>Обновляет контактные данные «всё или ничего».</summary>
    public void UpdateProfile(string phoneNumber, string email, string address)
    {
        var oldPhone = _phoneNumber;
        var oldEmail = _email;
        var oldAddress = _address;
        try
        {
            PhoneNumber = phoneNumber;
            Email = email;
            Address = address;
        }
        catch
        {
            _phoneNumber = oldPhone;
            _email = oldEmail;
            _address = oldAddress;
            throw;
        }
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Пациент #{PatientId}] {FullName}");
        Console.WriteLine($"   Дата рождения: {BirthDate:dd.MM.yyyy} (возраст: {GetAge()})");
        Console.WriteLine($"   Телефон: {PhoneNumber} | E-mail: {Email}");
        Console.WriteLine($"   Адрес: {Address}");
        Console.WriteLine($"   Записей на приём: {_appointments.Count}");
    }
}
