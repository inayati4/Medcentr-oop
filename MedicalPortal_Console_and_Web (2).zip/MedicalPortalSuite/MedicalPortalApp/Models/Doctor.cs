namespace MedicalPortalApp.Models;

public class Doctor : Person, IPayable
{
    public static readonly TimeSpan WorkDayStart = new(9, 0, 0);
    public static readonly TimeSpan WorkDayEnd = new(18, 0, 0);
    public static readonly TimeSpan SlotLength = TimeSpan.FromMinutes(30);

    private string _specialization = string.Empty;
    private int _experience;
    private int _cabinetNumber;
    private decimal _salary;

    private readonly List<Appointment> _appointments = new();

    public Doctor(int doctorId, string fullName, DateTime birthDate,
                  string specialization, int experience, int cabinetNumber, decimal salary)
        : base(doctorId, fullName, birthDate)
    {
        Specialization = specialization;
        Experience = experience;
        CabinetNumber = cabinetNumber;
        Salary = salary;
    }

    public int DoctorId => Id;

    public string Specialization
    {
        get => _specialization;
        private set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Специализация не может быть пустой.");
            _specialization = value.Trim();
        }
    }

    public int Experience
    {
        get => _experience;
        set
        {
            if (value < 0) throw new ArgumentException("Стаж не может быть отрицательным.");
            _experience = value;
        }
    }

    public int CabinetNumber
    {
        get => _cabinetNumber;
        set
        {
            if (value <= 0) throw new ArgumentException("Номер кабинета должен быть положительным.");
            _cabinetNumber = value;
        }
    }

    /// <summary>Базовый оклад.</summary>
    public decimal Salary
    {
        get => _salary;
        set
        {
            if (value < 0) throw new ArgumentException("Оклад не может быть отрицательным.");
            _salary = value;
        }
    }

    /// <summary>Отделение врача (может быть null — врач существует независимо).</summary>
    public Department? Department { get; internal set; }

    public IReadOnlyList<Appointment> Appointments => _appointments;      // 1 -> 0..*

    internal void AddAppointment(Appointment appointment) => _appointments.Add(appointment);

    public void UpdateSpecialization(string newSpecialization) => Specialization = newSpecialization;

    /// <summary>Оклад + 2% за каждый год стажа (максимум 25 лет) + 1000 за каждый завершённый приём.</summary>
    public decimal CalculateSalary()
    {
        decimal experienceBonus = Salary * 0.02m * Math.Min(Experience, 25);
        decimal visitsBonus = 1000m * _appointments.Count(a => a.Status == AppointmentStatus.Completed);
        return Salary + experienceBonus + visitsBonus;
    }

    public decimal CalculatePayment() => CalculateSalary();

    // ---------- Расписание (задачи 7, 8) ----------

    /// <summary>Попадает ли время в рабочий день (09:00–18:00, слоты по 30 минут).</summary>
    public static bool IsWorkingSlot(DateTime dateTime)
    {
        var t = dateTime.TimeOfDay;
        bool onGrid = t.Minutes % 30 == 0 && t.Seconds == 0 && t.Milliseconds == 0;
        return onGrid && t >= WorkDayStart && t + SlotLength <= WorkDayEnd;
    }

    /// <summary>Занят ли врач в указанное время.</summary>
    public bool IsBusyAt(DateTime dateTime) =>
        _appointments.Any(a => a.Status != AppointmentStatus.Cancelled && a.StartTime == dateTime);

    /// <summary>Свободен ли врач на указанные дату и время.</summary>
    public bool IsDoctorAvailable(DateTime date) => IsWorkingSlot(date) && !IsBusyAt(date);

    /// <summary>Свободные слоты врача на указанный день.</summary>
    public List<TimeSpan> GetFreeSlots(DateTime day)
    {
        var result = new List<TimeSpan>();
        for (var t = WorkDayStart; t + SlotLength <= WorkDayEnd; t += SlotLength)
        {
            if (!IsBusyAt(day.Date + t)) result.Add(t);
        }
        return result;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Врач #{DoctorId}] {FullName}");
        Console.WriteLine($"   Специализация: {Specialization} | Стаж: {Experience} лет | Кабинет: {CabinetNumber}");
        Console.WriteLine($"   Оклад: {Salary:N2} | К выплате: {CalculateSalary():N2}");
        Console.WriteLine($"   Отделение: {Department?.DepartmentName ?? "не назначено"}");
    }
}
