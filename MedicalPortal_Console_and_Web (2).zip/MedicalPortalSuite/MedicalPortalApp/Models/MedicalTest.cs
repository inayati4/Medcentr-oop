namespace MedicalPortalApp.Models;

public class MedicalTest
{
    public MedicalTest(int testId, string testName, DateTime testDate, Patient patient)
    {
        if (string.IsNullOrWhiteSpace(testName))
            throw new ArgumentException("Название анализа не может быть пустым.");
        ArgumentNullException.ThrowIfNull(patient);

        TestId = testId;
        TestName = testName.Trim();
        TestDate = testDate.Date;
        Patient = patient;
        patient.AddTest(this);
    }

    public int TestId { get; }
    public string TestName { get; }
    public DateTime TestDate { get; }
    public string? Result { get; private set; }
    public Patient Patient { get; }

    public void AddResult(string result)
    {
        if (string.IsNullOrWhiteSpace(result))
            throw new ArgumentException("Результат не может быть пустым.");
        if (Result != null)
            throw new InvalidOperationException("Результат уже внесён. Используйте UpdateResult().");
        Result = result.Trim();
    }

    public void UpdateResult(string newResult)
    {
        if (string.IsNullOrWhiteSpace(newResult))
            throw new ArgumentException("Результат не может быть пустым.");
        if (Result == null)
            throw new InvalidOperationException("Результата ещё нет. Используйте AddResult().");
        Result = newResult.Trim();
    }

    public void DisplayResult()
    {
        Console.WriteLine($"[Анализ #{TestId}] {TestName} от {TestDate:dd.MM.yyyy} | Пациент: {Patient.FullName}");
        Console.WriteLine($"   Результат: {Result ?? "ожидается"}");
    }
}
