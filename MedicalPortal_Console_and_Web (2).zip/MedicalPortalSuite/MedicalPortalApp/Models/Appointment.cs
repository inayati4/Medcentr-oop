namespace MedicalPortalApp.Models;

public class Appointment
{
    private Appointment(int appointmentId, Patient patient, Doctor doctor, DateTime date, TimeSpan time)
    {
        AppointmentId = appointmentId;
        Patient = patient;
        Doctor = doctor;
        AppointmentDate = date.Date;
        AppointmentTime = time;
        Status = AppointmentStatus.Scheduled;
    }

    public int AppointmentId { get; }
    public Patient Patient { get; }        // * -> 1
    public Doctor Doctor { get; }          // * -> 1
    public DateTime AppointmentDate { get; }
    public TimeSpan AppointmentTime { get; }
    public AppointmentStatus Status { get; private set; }

    public DateTime StartTime => AppointmentDate + AppointmentTime;

    /// <summary>Создаёт запись; при невозможности возвращает null и текст причины в error.</summary>
    public static Appointment? TryCreate(int appointmentId, Patient patient, Doctor doctor,
                                         DateTime date, TimeSpan time, out string? error)
    {
        ArgumentNullException.ThrowIfNull(patient);
        ArgumentNullException.ThrowIfNull(doctor);

        var start = date.Date + time;
        error = null;

        if (start < DateTime.Now)
        {
            error = "Нельзя записаться на прошедшее время!";
            return null;
        }
        if (!Doctor.IsWorkingSlot(start))
        {
            error = "Время вне графика врача (приём 09:00–18:00, слоты по 30 минут)!";
            return null;
        }
        if (doctor.IsBusyAt(start))                                   // защита от двойной записи (задача 8)
        {
            error = "Врач уже занят на указанное время!";
            return null;
        }

        var appointment = new Appointment(appointmentId, patient, doctor, date, time);
        patient.AddAppointment(appointment);
        doctor.AddAppointment(appointment);
        return appointment;
    }

    /// <summary>Консольная версия: печатает причину отказа.</summary>
    public static Appointment? CreateAppointment(int appointmentId, Patient patient, Doctor doctor,
                                                 DateTime date, TimeSpan time)
    {
        var appointment = TryCreate(appointmentId, patient, doctor, date, time, out var error);
        if (appointment == null) Console.WriteLine(error);
        return appointment;
    }

    public bool TryCancel(out string? error)
    {
        error = null;
        if (Status == AppointmentStatus.Cancelled) { error = "Запись уже отменена."; return false; }
        if (Status == AppointmentStatus.Completed) { error = "Нельзя отменить уже завершённый приём."; return false; }
        Status = AppointmentStatus.Cancelled;
        return true;
    }

    public bool TryConfirm(out string? error)
    {
        error = null;
        if (Status != AppointmentStatus.Scheduled)
        {
            error = $"Подтвердить можно только запланированную запись (сейчас: {Status.ToRussian()}).";
            return false;
        }
        Status = AppointmentStatus.Confirmed;
        return true;
    }

    public bool TryComplete(out string? error)
    {
        error = null;
        if (Status == AppointmentStatus.Cancelled || Status == AppointmentStatus.Completed)
        {
            error = $"Нельзя завершить приём в статусе «{Status.ToRussian()}».";
            return false;
        }
        Status = AppointmentStatus.Completed;
        return true;
    }

    public bool CancelAppointment() => Report(TryCancel(out var e), e);
    public bool ConfirmAppointment() => Report(TryConfirm(out var e), e);
    public bool CompleteAppointment() => Report(TryComplete(out var e), e);

    private static bool Report(bool ok, string? error)
    {
        if (!ok) Console.WriteLine(error);
        return ok;
    }

    public void DisplayAppointment()
    {
        Console.WriteLine($"[Запись #{AppointmentId}] {AppointmentDate:dd.MM.yyyy} {AppointmentTime:hh\\:mm} | " +
                          $"Пациент: {Patient.FullName} | Врач: {Doctor.FullName} ({Doctor.Specialization}) | " +
                          $"Статус: {Status.ToRussian()}");
    }
}
