namespace MedicalPortalApp.Models;

/// <summary>
/// Медицинская карта. Составная часть пациента (композиция): конструктор internal,
/// карту нельзя создать отдельно от Patient.
/// </summary>
public class MedicalRecord
{
    private readonly List<string> _medicalHistory = new();

    internal MedicalRecord(int recordId, Patient patient)
    {
        RecordId = recordId;
        Patient = patient;
        CreationDate = DateTime.Now;
    }

    public int RecordId { get; }
    public Patient Patient { get; }
    public string Diagnosis { get; private set; } = "не установлен";
    public IReadOnlyList<string> MedicalHistory => _medicalHistory;
    public DateTime CreationDate { get; }

    public void AddDiagnosis(string diagnosis)
    {
        if (string.IsNullOrWhiteSpace(diagnosis))
            throw new ArgumentException("Диагноз не может быть пустым.");
        Diagnosis = diagnosis.Trim();
        _medicalHistory.Add($"{DateTime.Now:dd.MM.yyyy}: установлен диагноз «{Diagnosis}»");
    }

    public void UpdateHistory(string note)
    {
        if (string.IsNullOrWhiteSpace(note))
            throw new ArgumentException("Запись в истории болезни не может быть пустой.");
        _medicalHistory.Add($"{DateTime.Now:dd.MM.yyyy}: {note.Trim()}");
    }

    public void DisplayRecord()
    {
        Console.WriteLine($"[Медкарта #{RecordId}] Пациент: {Patient.FullName}");
        Console.WriteLine($"   Создана: {CreationDate:dd.MM.yyyy}");
        Console.WriteLine($"   Диагноз: {Diagnosis}");
        if (_medicalHistory.Count == 0)
        {
            Console.WriteLine("   История болезни пуста.");
            return;
        }
        Console.WriteLine("   История болезни:");
        foreach (var line in _medicalHistory)
            Console.WriteLine($"     - {line}");
    }
}
