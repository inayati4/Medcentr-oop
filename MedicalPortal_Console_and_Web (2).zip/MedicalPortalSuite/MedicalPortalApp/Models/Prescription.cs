namespace MedicalPortalApp.Models;

public class Prescription
{
    private string _medicationName = string.Empty;
    private string _dosage = string.Empty;
    private int _duration;

    private Prescription(int prescriptionId, Patient patient, Doctor doctor,
                         string medicationName, string dosage, int durationDays)
    {
        PrescriptionId = prescriptionId;
        Patient = patient;
        Doctor = doctor;
        Apply(medicationName, dosage, durationDays);
    }

    public int PrescriptionId { get; }
    public Patient Patient { get; }
    public Doctor Doctor { get; }
    public string MedicationName => _medicationName;
    public string Dosage => _dosage;
    /// <summary>Длительность курса в днях.</summary>
    public int Duration => _duration;

    public static Prescription CreatePrescription(int prescriptionId, Patient patient, Doctor doctor,
                                                  string medicationName, string dosage, int durationDays)
    {
        ArgumentNullException.ThrowIfNull(patient);
        ArgumentNullException.ThrowIfNull(doctor);
        var prescription = new Prescription(prescriptionId, patient, doctor, medicationName, dosage, durationDays);
        patient.AddPrescription(prescription);
        return prescription;
    }

    public void UpdatePrescription(string medicationName, string dosage, int durationDays) =>
        Apply(medicationName, dosage, durationDays);

    private void Apply(string medicationName, string dosage, int durationDays)
    {
        if (string.IsNullOrWhiteSpace(medicationName))
            throw new ArgumentException("Название препарата не может быть пустым.");
        if (string.IsNullOrWhiteSpace(dosage))
            throw new ArgumentException("Дозировка не может быть пустой.");
        if (durationDays <= 0)
            throw new ArgumentException("Длительность курса должна быть больше нуля.");
        _medicationName = medicationName.Trim();
        _dosage = dosage.Trim();
        _duration = durationDays;
    }

    public void DisplayPrescription()
    {
        Console.WriteLine($"[Назначение #{PrescriptionId}] Пациент: {Patient.FullName} | Врач: {Doctor.FullName}");
        Console.WriteLine($"   Препарат: {MedicationName}, дозировка: {Dosage}, курс: {Duration} дн.");
    }
}
