namespace MedicalPortalApp.Models;

/// <summary>Состояние записи на приём (задача 20).</summary>
public enum AppointmentStatus
{
    Scheduled,
    Confirmed,
    Completed,
    Cancelled
}

public enum PaymentStatus
{
    Pending,
    Paid,
    Refunded
}

public static class StatusExtensions
{
    public static string ToRussian(this AppointmentStatus status) => status switch
    {
        AppointmentStatus.Scheduled => "Запланирован",
        AppointmentStatus.Confirmed => "Подтверждён",
        AppointmentStatus.Completed => "Завершён",
        AppointmentStatus.Cancelled => "Отменён",
        _ => status.ToString()
    };

    public static string ToRussian(this PaymentStatus status) => status switch
    {
        PaymentStatus.Pending => "Ожидает оплаты",
        PaymentStatus.Paid => "Оплачен",
        PaymentStatus.Refunded => "Возвращён",
        _ => status.ToString()
    };
}
