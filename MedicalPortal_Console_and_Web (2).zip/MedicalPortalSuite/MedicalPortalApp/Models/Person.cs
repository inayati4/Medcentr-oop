namespace MedicalPortalApp.Models;

/// <summary>Абстрактный базовый класс для людей в системе (задачи 16, 19).</summary>
public abstract class Person
{
    private string _fullName = string.Empty;
    private DateTime _birthDate;

    protected Person(int id, string fullName, DateTime birthDate)
    {
        Id = id;
        FullName = fullName;
        BirthDate = birthDate;
    }

    public int Id { get; }

    public string FullName
    {
        get => _fullName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("ФИО не может быть пустым.");
            _fullName = value.Trim();
        }
    }

    public DateTime BirthDate
    {
        get => _birthDate;
        set
        {
            if (value.Date > DateTime.Today)
                throw new ArgumentException("Дата рождения не может быть в будущем (возраст не может быть отрицательным).");
            if (value.Date < DateTime.Today.AddYears(-130))
                throw new ArgumentException("Указан недопустимый возраст.");
            _birthDate = value.Date;
        }
    }

    public int GetAge()
    {
        var today = DateTime.Today;
        int age = today.Year - BirthDate.Year;
        if (BirthDate.Date > today.AddYears(-age)) age--;
        return age;
    }

    public abstract void DisplayInfo();
}
