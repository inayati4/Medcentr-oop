namespace MedicalPortalApp.Models;

/// <summary>Объект, для которого можно рассчитать выплату или сумму к оплате (задача 18).</summary>
public interface IPayable
{
    decimal CalculatePayment();
}
