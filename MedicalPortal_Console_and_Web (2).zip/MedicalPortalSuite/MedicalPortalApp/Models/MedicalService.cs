namespace MedicalPortalApp.Models;

public class MedicalService
{
    private string _serviceName = string.Empty;
    private decimal _price;
    private int _duration;

    public MedicalService(int serviceId, string serviceName, string description, decimal price, int durationMinutes)
    {
        ServiceId = serviceId;
        ServiceName = serviceName;
        Description = description ?? string.Empty;
        Price = price;
        Duration = durationMinutes;
    }

    public int ServiceId { get; }

    public string ServiceName
    {
        get => _serviceName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название услуги не может быть пустым.");
            _serviceName = value.Trim();
        }
    }

    public string Description { get; set; }

    public decimal Price
    {
        get => _price;
        private set
        {
            if (value < 0) throw new ArgumentException("Стоимость услуги не может быть меньше нуля.");
            _price = value;
        }
    }

    /// <summary>Длительность в минутах.</summary>
    public int Duration
    {
        get => _duration;
        set
        {
            if (value <= 0) throw new ArgumentException("Длительность должна быть больше нуля.");
            _duration = value;
        }
    }

    /// <summary>Итоговая цена: Price × количество − скидка в процентах.</summary>
    public decimal CalculatePrice(int quantity = 1, decimal discountPercent = 0)
    {
        if (quantity <= 0) throw new ArgumentException("Количество должно быть больше нуля.");
        if (discountPercent < 0 || discountPercent > 100)
            throw new ArgumentException("Скидка должна быть в диапазоне от 0 до 100%.");
        return Price * quantity * (1 - discountPercent / 100m);
    }

    public void UpdatePrice(decimal newPrice) => Price = newPrice;

    public void DisplayService()
    {
        Console.WriteLine($"[Услуга #{ServiceId}] {ServiceName} — {Price:N2} тг, {Duration} мин.");
        if (!string.IsNullOrWhiteSpace(Description))
            Console.WriteLine($"   {Description}");
    }
}
