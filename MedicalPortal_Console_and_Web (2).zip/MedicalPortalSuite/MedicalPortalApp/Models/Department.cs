namespace MedicalPortalApp.Models;

/// <summary>Отделение. Агрегация с Doctor: врач может существовать без отделения (задача 13).</summary>
public class Department
{
    private string _departmentName = string.Empty;
    private string _phoneNumber = string.Empty;
    private Doctor? _headDoctor;
    private readonly List<Doctor> _doctors = new();

    public Department(int departmentId, string departmentName, int floor, string phoneNumber)
    {
        DepartmentId = departmentId;
        DepartmentName = departmentName;
        Floor = floor;
        PhoneNumber = phoneNumber;
    }

    public int DepartmentId { get; }

    public string DepartmentName
    {
        get => _departmentName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название отделения не может быть пустым.");
            _departmentName = value.Trim();
        }
    }

    public int Floor { get; set; }

    public string PhoneNumber
    {
        get => _phoneNumber;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Телефон отделения не может быть пустым.");
            _phoneNumber = value.Trim();
        }
    }

    public Doctor? HeadDoctor
    {
        get => _headDoctor;
        set
        {
            if (value != null && !_doctors.Contains(value))
                throw new ArgumentException("Заведующий должен работать в этом отделении.");
            _headDoctor = value;
        }
    }

    public IReadOnlyList<Doctor> Doctors => _doctors;

    public void AddDoctor(Doctor doctor)
    {
        ArgumentNullException.ThrowIfNull(doctor);
        if (_doctors.Contains(doctor))
        {
            Console.WriteLine("Этот врач уже работает в отделении.");
            return;
        }
        doctor.Department?.RemoveDoctor(doctor);   // врач работает только в одном отделении
        _doctors.Add(doctor);
        doctor.Department = this;
    }

    public void RemoveDoctor(Doctor doctor)
    {
        ArgumentNullException.ThrowIfNull(doctor);
        if (!_doctors.Remove(doctor))
        {
            Console.WriteLine("Такого врача в отделении нет.");
            return;
        }
        if (_headDoctor == doctor) _headDoctor = null;
        doctor.Department = null;                  // сам врач при этом остаётся в системе
    }

    public void DisplayDoctors()
    {
        Console.WriteLine($"Отделение «{DepartmentName}» (этаж {Floor}, тел. {PhoneNumber})");
        Console.WriteLine($"   Заведующий: {HeadDoctor?.FullName ?? "не назначен"}");
        if (_doctors.Count == 0)
        {
            Console.WriteLine("   Врачей в отделении нет.");
            return;
        }
        foreach (var d in _doctors)
            Console.WriteLine($"   - #{d.DoctorId} {d.FullName} ({d.Specialization}), каб. {d.CabinetNumber}");
    }
}
