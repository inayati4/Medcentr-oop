# Медицинский портал (C# / .NET 8)

Запуск:

    dotnet run

Структура: `Models/` — предметные классы, `Services/MedicalPortal.cs` — логика портала,
`UI/ConsoleMenu.cs` — меню, `docs/` — UML-диаграмма и отчёт.
