using System.Globalization;
using MedicalPortalApp.Models;
using MedicalPortalApp.Services;

namespace MedicalPortalApp.UI;

/// <summary>Консольное главное меню (задача 25).</summary>
public class ConsoleMenu
{
    private readonly MedicalPortal _portal;

    public ConsoleMenu(MedicalPortal portal) => _portal = portal;

    public void Run()
    {
        while (true)
        {
            PrintMenu();
            int choice = ReadInt("Выберите действие: ", 0, 17);
            Console.WriteLine();
            if (choice == 0)
            {
                Console.WriteLine("До свидания!");
                return;
            }

            try
            {
                Execute(choice);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Ошибка данных: {ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Операция невозможна: {ex.Message}");
            }

            Console.WriteLine();
            Console.Write("Нажмите Enter для продолжения...");
            Console.ReadLine();
            Console.WriteLine();
        }
    }

    private static void PrintMenu()
    {
        Console.WriteLine("========== MEDICAL PORTAL ==========");
        Console.WriteLine();
        Console.WriteLine("1. Добавить пациента");
        Console.WriteLine("2. Добавить врача");
        Console.WriteLine("3. Показать всех пациентов");
        Console.WriteLine("4. Показать всех врачей");
        Console.WriteLine("5. Записать пациента на приём");
        Console.WriteLine("6. Отменить запись");
        Console.WriteLine("7. Показать расписание врача");
        Console.WriteLine("8. Добавить медицинский анализ");
        Console.WriteLine("9. Создать медицинское назначение");
        Console.WriteLine("10. Оплатить услугу");
        Console.WriteLine("11. Поиск пациента");
        Console.WriteLine("12. Статистика портала");
        Console.WriteLine("--- дополнительно ---");
        Console.WriteLine("13. Подтвердить запись");
        Console.WriteLine("14. Завершить приём");
        Console.WriteLine("15. Вернуть платёж");
        Console.WriteLine("16. Показать медицинскую карту пациента");
        Console.WriteLine("17. Установить диагноз пациенту");
        Console.WriteLine("0. Выход");
        Console.WriteLine();
    }

    private void Execute(int choice)
    {
        switch (choice)
        {
            case 1: AddPatient(); break;
            case 2: AddDoctor(); break;
            case 3: ShowPatients(); break;
            case 4: ShowDoctors(); break;
            case 5: BookAppointment(); break;
            case 6: CancelAppointment(); break;
            case 7: ShowSchedule(); break;
            case 8: AddTest(); break;
            case 9: CreatePrescription(); break;
            case 10: Pay(); break;
            case 11: SearchPatient(); break;
            case 12: ShowStatistics(); break;
            case 13: ConfirmAppointment(); break;
            case 14: CompleteAppointment(); break;
            case 15: Refund(); break;
            case 16: ShowRecord(); break;
            case 17: AddDiagnosis(); break;
        }
    }

    // ---------- Действия ----------

    private void AddPatient()
    {
        var name = ReadString("ФИО: ");
        var birth = ReadDate("Дата рождения (дд.мм.гггг): ");
        var phone = ReadString("Телефон: ");
        var email = ReadString("E-mail: ");
        var address = ReadString("Адрес: ");
        var patient = _portal.AddPatient(name, birth, phone, email, address);
        Console.WriteLine($"Пациент добавлен. ID = {patient.PatientId}");
    }

    private void AddDoctor()
    {
        var name = ReadString("ФИО: ");
        var birth = ReadDate("Дата рождения (дд.мм.гггг): ");
        var specialization = ReadString("Специализация: ");
        int experience = ReadInt("Стаж (лет): ", 0, 70);
        int cabinet = ReadInt("Номер кабинета: ", 1, 9999);
        decimal salary = ReadDecimal("Оклад: ");
        var doctor = _portal.AddDoctor(name, birth, specialization, experience, cabinet, salary);

        if (_portal.Departments.Count > 0)
        {
            Console.WriteLine("Отделения:");
            foreach (var d in _portal.Departments)
                Console.WriteLine($"  {d.DepartmentId}. {d.DepartmentName}");
            int depId = ReadInt("ID отделения (0 — без отделения): ", 0, int.MaxValue);
            if (depId != 0)
            {
                var dep = _portal.FindDepartmentById(depId);
                if (dep == null) Console.WriteLine("Отделение не найдено — врач добавлен без отделения.");
                else dep.AddDoctor(doctor);
            }
        }
        Console.WriteLine($"Врач добавлен. ID = {doctor.DoctorId}");
    }

    private void ShowPatients()
    {
        if (_portal.Patients.Count == 0) { Console.WriteLine("Список пациентов пуст."); return; }
        foreach (var p in _portal.Patients) p.DisplayInfo();
    }

    private void ShowDoctors()
    {
        if (_portal.Doctors.Count == 0) { Console.WriteLine("Список врачей пуст."); return; }
        foreach (var d in _portal.Doctors) d.DisplayInfo();
    }

    private void BookAppointment()
    {
        var patient = ReadPatient(); if (patient == null) return;
        var doctor = ReadDoctor(); if (doctor == null) return;
        var date = ReadDate("Дата приёма (дд.мм.гггг): ");

        var free = doctor.GetFreeSlots(date);
        Console.WriteLine(free.Count == 0
            ? "На эту дату свободных слотов нет."
            : "Свободное время: " + string.Join(", ", free.Select(t => t.ToString(@"hh\:mm"))));
        if (free.Count == 0) return;

        var time = ReadTime("Время приёма (чч:мм): ");
        var appointment = _portal.BookAppointment(patient, doctor, date, time);
        if (appointment != null)
        {
            Console.WriteLine("Запись создана:");
            appointment.DisplayAppointment();
        }
    }

    private void CancelAppointment()
    {
        var appointment = ReadAppointment(); if (appointment == null) return;
        if (appointment.CancelAppointment()) Console.WriteLine("Запись отменена.");
    }

    private void ConfirmAppointment()
    {
        var appointment = ReadAppointment(); if (appointment == null) return;
        if (appointment.ConfirmAppointment()) Console.WriteLine("Запись подтверждена.");
    }

    private void CompleteAppointment()
    {
        var appointment = ReadAppointment(); if (appointment == null) return;
        if (appointment.CompleteAppointment()) Console.WriteLine("Приём завершён.");
    }

    private void ShowSchedule()
    {
        var doctor = ReadDoctor(); if (doctor == null) return;
        var date = ReadDate("Дата (дд.мм.гггг): ");
        var list = _portal.GetDoctorSchedule(doctor, date).ToList();

        Console.WriteLine($"Расписание: {doctor.FullName}, {date:dd.MM.yyyy}");
        if (list.Count == 0) Console.WriteLine("Записей нет.");
        else foreach (var a in list) a.DisplayAppointment();

        var free = doctor.GetFreeSlots(date);
        Console.WriteLine("Свободно: " + (free.Count == 0 ? "нет" : string.Join(", ", free.Select(t => t.ToString(@"hh\:mm")))));
    }

    private void AddTest()
    {
        var patient = ReadPatient(); if (patient == null) return;
        var name = ReadString("Название анализа: ");
        var date = ReadOptionalDate("Дата анализа (дд.мм.гггг, Enter — сегодня): ") ?? DateTime.Today;
        Console.Write("Результат (Enter — ожидается): ");
        var result = Console.ReadLine();
        var test = _portal.AddMedicalTest(patient, name, date, result);
        test.DisplayResult();
    }

    private void CreatePrescription()
    {
        var patient = ReadPatient(); if (patient == null) return;
        var doctor = ReadDoctor(); if (doctor == null) return;
        var medication = ReadString("Препарат: ");
        var dosage = ReadString("Дозировка: ");
        int days = ReadInt("Длительность курса (дней): ", 1, 365);
        var prescription = _portal.CreatePrescription(patient, doctor, medication, dosage, days);
        Console.WriteLine("Назначение создано:");
        prescription.DisplayPrescription();
    }

    private void Pay()
    {
        var patient = ReadPatient(); if (patient == null) return;
        if (_portal.Services.Count == 0) { Console.WriteLine("Каталог услуг пуст."); return; }

        foreach (var s in _portal.Services) s.DisplayService();
        int serviceId = ReadInt("ID услуги: ", 1, int.MaxValue);
        var service = _portal.FindServiceById(serviceId);
        if (service == null) { Console.WriteLine($"Услуга с ID {serviceId} не найдена."); return; }

        int quantity = ReadInt("Количество: ", 1, 100);
        var payment = _portal.PayForService(patient, service, quantity);
        Console.WriteLine("Оплата прошла успешно:");
        payment.DisplayPayment();
    }

    private void Refund()
    {
        int id = ReadInt("ID платежа: ", 1, int.MaxValue);
        var payment = _portal.FindPaymentById(id);
        if (payment == null) { Console.WriteLine($"Платёж с ID {id} не найден."); return; }
        if (payment.RefundPayment()) Console.WriteLine("Платёж возвращён.");
    }

    private void SearchPatient()
    {
        Console.WriteLine("Искать по: 1 — ID, 2 — ФИО, 3 — телефону");
        int mode = ReadInt("Ваш выбор: ", 1, 3);
        var found = new List<Patient>();

        switch (mode)
        {
            case 1:
                var byId = _portal.FindPatientById(ReadInt("ID: ", 1, int.MaxValue));
                if (byId != null) found.Add(byId);
                break;
            case 2:
                found = _portal.SearchPatientsByName(ReadString("ФИО (или часть): "));
                break;
            case 3:
                found = _portal.SearchPatientsByPhone(ReadString("Телефон (или часть): "));
                break;
        }

        if (found.Count == 0) Console.WriteLine("Пациент не найден. Проверьте введённые данные и попробуйте снова.");
        else foreach (var p in found) p.DisplayInfo();
    }

    private void ShowStatistics()
    {
        var s = _portal.GetStatistics();
        Console.WriteLine("----- Статистика портала -----");
        Console.WriteLine($"Пациентов:            {s.Patients}");
        Console.WriteLine($"Врачей:               {s.Doctors}");
        Console.WriteLine($"Записей на приём:     {s.Appointments}");
        Console.WriteLine($"Завершённых приёмов:  {s.CompletedAppointments}");
        Console.WriteLine($"Оплачено услуг на:    {s.TotalPaid:N2} тг");
    }

    private void ShowRecord()
    {
        var patient = ReadPatient(); if (patient == null) return;
        patient.Record.DisplayRecord();
    }

    private void AddDiagnosis()
    {
        var patient = ReadPatient(); if (patient == null) return;
        patient.Record.AddDiagnosis(ReadString("Диагноз: "));
        Console.WriteLine("Диагноз сохранён в медицинской карте.");
    }

    // ---------- Выбор объектов ----------

    private Patient? ReadPatient()
    {
        int id = ReadInt("ID пациента: ", 1, int.MaxValue);
        var patient = _portal.FindPatientById(id);
        if (patient == null) Console.WriteLine($"Пациент с ID {id} не найден.");
        return patient;
    }

    private Doctor? ReadDoctor()
    {
        int id = ReadInt("ID врача: ", 1, int.MaxValue);
        var doctor = _portal.FindDoctorById(id);
        if (doctor == null) Console.WriteLine($"Врач с ID {id} не найден.");
        return doctor;
    }

    private Appointment? ReadAppointment()
    {
        int id = ReadInt("ID записи: ", 1, int.MaxValue);
        var appointment = _portal.FindAppointmentById(id);
        if (appointment == null) Console.WriteLine($"Запись с ID {id} не найдена.");
        return appointment;
    }

    // ---------- Безопасный ввод ----------

    private static string? ReadLine()
    {
        var line = Console.ReadLine();
        if (line == null) throw new EndOfStreamException("Ввод завершён.");
        return line;
    }

    private static string ReadString(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = ReadLine()?.Trim();
            if (!string.IsNullOrEmpty(s)) return s;
            Console.WriteLine("Поле не может быть пустым.");
        }
    }

    private static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(ReadLine()?.Trim(), out int value) && value >= min && value <= max)
                return value;
            Console.WriteLine("Введите корректное целое число.");
        }
    }

    private static decimal ReadDecimal(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = ReadLine()?.Trim().Replace(',', '.');
            if (decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal value) && value >= 0)
                return value;
            Console.WriteLine("Введите неотрицательное число.");
        }
    }

    private static DateTime ReadDate(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            if (DateTime.TryParseExact(ReadLine()?.Trim(), "dd.MM.yyyy", CultureInfo.InvariantCulture,
                                       DateTimeStyles.None, out var date))
                return date;
            Console.WriteLine("Неверный формат. Пример: 25.12.2026");
        }
    }

    private static DateTime? ReadOptionalDate(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = ReadLine()?.Trim();
            if (string.IsNullOrEmpty(s)) return null;
            if (DateTime.TryParseExact(s, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
                return date;
            Console.WriteLine("Неверный формат. Пример: 25.12.2026");
        }
    }

    private static TimeSpan ReadTime(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            if (DateTime.TryParseExact(ReadLine()?.Trim(), new[] { "H:mm", "HH:mm" }, CultureInfo.InvariantCulture,
                                       DateTimeStyles.None, out var time))
                return time.TimeOfDay;
            Console.WriteLine("Неверный формат. Пример: 09:30");
        }
    }
}
