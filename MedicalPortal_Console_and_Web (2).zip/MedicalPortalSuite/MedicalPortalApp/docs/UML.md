# UML-диаграмма «Медицинский портал»

Диаграмма написана на Mermaid. Открыть: GitHub, VS Code (расширение «Markdown Preview Mermaid Support»)
или вставить код на https://mermaid.live

```mermaid
classDiagram
direction TB

class Person {
    <<abstract>>
    -string _fullName
    -DateTime _birthDate
    +int Id
    +string FullName
    +DateTime BirthDate
    +GetAge() int
    +DisplayInfo()* void
}

class Patient {
    -string _phoneNumber
    -string _email
    -string _address
    +int PatientId
    +string PhoneNumber
    +string Email
    +string Address
    +MedicalRecord Record
    +UpdateProfile(phone, email, address) void
    +DisplayInfo() void
}

class Doctor {
    -string _specialization
    -int _experience
    -int _cabinetNumber
    -decimal _salary
    +int DoctorId
    +string Specialization
    +int Experience
    +int CabinetNumber
    +decimal Salary
    +UpdateSpecialization(spec) void
    +CalculateSalary() decimal
    +CalculatePayment() decimal
    +IsDoctorAvailable(date) bool
    +GetFreeSlots(day) List~TimeSpan~
    +DisplayInfo() void
}

class IPayable {
    <<interface>>
    +CalculatePayment() decimal
}

class Department {
    +int DepartmentId
    +string DepartmentName
    +int Floor
    +string PhoneNumber
    +Doctor HeadDoctor
    +AddDoctor(doctor) void
    +RemoveDoctor(doctor) void
    +DisplayDoctors() void
}

class MedicalService {
    -decimal _price
    +int ServiceId
    +string ServiceName
    +string Description
    +decimal Price
    +int Duration
    +CalculatePrice(qty, discount) decimal
    +UpdatePrice(price) void
    +DisplayService() void
}

class Appointment {
    +int AppointmentId
    +Patient Patient
    +Doctor Doctor
    +DateTime AppointmentDate
    +TimeSpan AppointmentTime
    +AppointmentStatus Status
    +CreateAppointment(...)$ Appointment
    +CancelAppointment() bool
    +ConfirmAppointment() bool
    +CompleteAppointment() bool
    +DisplayAppointment() void
}

class AppointmentStatus {
    <<enumeration>>
    Scheduled
    Confirmed
    Completed
    Cancelled
}

class MedicalRecord {
    +int RecordId
    +Patient Patient
    +string Diagnosis
    +List~string~ MedicalHistory
    +DateTime CreationDate
    +AddDiagnosis(text) void
    +UpdateHistory(note) void
    +DisplayRecord() void
}

class MedicalTest {
    +int TestId
    +string TestName
    +DateTime TestDate
    +string Result
    +Patient Patient
    +AddResult(result) void
    +UpdateResult(result) void
    +DisplayResult() void
}

class Prescription {
    +int PrescriptionId
    +Patient Patient
    +Doctor Doctor
    +string MedicationName
    +string Dosage
    +int Duration
    +CreatePrescription(...)$ Prescription
    +UpdatePrescription(...) void
    +DisplayPrescription() void
}

class Payment {
    +int PaymentId
    +Patient Patient
    +decimal Amount
    +DateTime PaymentDate
    +PaymentStatus PaymentStatus
    +MakePayment() bool
    +RefundPayment() bool
    +CalculatePayment() decimal
    +DisplayPayment() void
}

class PaymentStatus {
    <<enumeration>>
    Pending
    Paid
    Refunded
}

class MedicalPortal {
    -List~Patient~ _patients
    -List~Doctor~ _doctors
    -List~Appointment~ _appointments
    -List~Payment~ _payments
    +AddPatient(...) Patient
    +AddDoctor(...) Doctor
    +BookAppointment(...) Appointment
    +PayForService(...) Payment
    +SearchPatientsByName(q) List~Patient~
    +SearchPatientsByPhone(q) List~Patient~
    +GetStatistics() PortalStatistics
}

Person <|-- Patient : наследование
Person <|-- Doctor : наследование
IPayable <|.. Doctor : реализует
IPayable <|.. Payment : реализует

Patient "1" -- "0..*" Appointment : записан
Doctor "1" -- "0..*" Appointment : принимает
Department "0..1" o-- "0..*" Doctor : агрегация
Patient "1" *-- "1" MedicalRecord : композиция
Patient "1" -- "0..*" MedicalTest : сдаёт
Patient "1" -- "0..*" Prescription : получает
Doctor "1" -- "0..*" Prescription : выписывает
Patient "1" -- "0..*" Payment : оплачивает
Appointment ..> AppointmentStatus
Payment ..> PaymentStatus
MedicalPortal "1" o-- "0..*" Patient
MedicalPortal "1" o-- "0..*" Doctor
MedicalPortal "1" o-- "0..*" Department
MedicalPortal "1" o-- "0..*" MedicalService
MedicalPortal "1" o-- "0..*" Appointment
MedicalPortal "1" o-- "0..*" Payment
```

## Обоснование связи Patient — MedicalRecord (задача 14)

Выбрана **композиция**. Медицинская карта создаётся внутри конструктора `Patient`,
конструктор `MedicalRecord` помечен `internal`, поэтому отдельно от пациента карта существовать не может,
а её время жизни совпадает со временем жизни записи пациента.

## Обоснование Department — Doctor (задача 13)

Выбрана **агрегация**: отделение хранит список врачей, но `Doctor` создаётся независимо
(`Department` у врача может быть `null`), а при `RemoveDoctor()` врач остаётся в системе.
