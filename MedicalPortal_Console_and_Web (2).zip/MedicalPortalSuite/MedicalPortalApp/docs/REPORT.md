# Отчёт: проект «Медицинский портал» (C#, .NET SDK 8)

## 1. Анализ архитектуры (задача 1)

Проект создан с нуля, поэтому все классы — новые.

| Раздел | Классы |
| --- | --- |
| Базовая модель | `Person` (abstract) |
| Пациенты | `Patient`, `MedicalRecord`, `MedicalTest`, `Prescription` |
| Врачи и отделения | `Doctor`, `Department` |
| Приёмы и услуги | `Appointment`, `AppointmentStatus`, `MedicalService` |
| Финансы | `Payment`, `PaymentStatus`, `IPayable` |
| Управление | `MedicalPortal` (данные и операции), `ConsoleMenu` (интерфейс) |

Итого 11 классов, 1 абстрактный класс, 1 интерфейс, 2 перечисления.

## 2. Где что реализовано

| Задачи | Реализация |
| --- | --- |
| 2–5, 9, 10, 21, 22 | `Patient`, `Doctor`, `Department`, `MedicalService`, `MedicalRecord`, `MedicalTest`, `Payment`, `Prescription` |
| 6 | `Appointment` (`CreateAppointment`, `CancelAppointment`, `ConfirmAppointment`, `DisplayAppointment`, плюс `CompleteAppointment`) |
| 7 | `Doctor.IsDoctorAvailable(DateTime)`: рабочее время 09:00–18:00, слоты по 30 минут, слот не занят |
| 8 | `Appointment.CreateAppointment` → «Врач уже занят на указанное время!» |
| 11, 12 | `Patient.Appointments`, `Doctor.Appointments`, `Appointment.Patient`, `Appointment.Doctor` |
| 13 | Агрегация: `Department.Doctors`, `Doctor.Department` (nullable) |
| 14 | Композиция: `MedicalRecord` создаётся в конструкторе `Patient` |
| 15 | `docs/UML.md` (15 классов, кратности, модификаторы) |
| 16, 17 | `Person` → `Patient`, `Doctor` с `override DisplayInfo()` |
| 18 | `IPayable` реализован в `Doctor` и `Payment` |
| 19 | Приватные поля, свойства с проверками (возраст ≥ 0, цена ≥ 0, контакты не пустые) |
| 20 | `enum AppointmentStatus` |
| 23 | `MedicalPortal.FindPatientById`, `SearchPatientsByName`, `SearchPatientsByPhone` |
| 24 | `MedicalPortal.GetStatistics()` |
| 25 | `ConsoleMenu` (пункты 1–12 из задания + 13–17 дополнительно) |

## 3. Принятые решения

- Зарплата врача: оклад + 2% за год стажа (максимум 25 лет) + 1000 за каждый завершённый приём.
- Чтобы статистика «завершённые приёмы» вообще могла меняться, добавлены пункты меню 13 (подтвердить), 14 (завершить), 15 (вернуть платёж), 16–17 (медкарта).
- Валюта в выводе — «тг».
- При запуске подгружаются демо-данные (2 отделения, 2 врача, 2 пациента, 3 услуги).

## 4. Сценарии для проверки

1. Пункт 5: записать пациента 1 к врачу 1 на завтра 10:00 → запись создана.
2. Повторить то же время для пациента 2 → «Врач уже занят на указанное время!».
3. Пункт 6: отменить запись → снова записать на 10:00 → теперь успешно.
4. Пункт 1: ввести телефон `abc` → ошибка валидации, пациент не добавлен.
5. Пункт 14 (завершить приём) → пункт 10 (оплата) → пункт 12: счётчики и сумма изменились.
6. Пункт 15 (возврат) → пункт 12: сумма оплаченных услуг уменьшилась.
7. Пункт 11: поиск по несуществующему ID → понятное сообщение.
