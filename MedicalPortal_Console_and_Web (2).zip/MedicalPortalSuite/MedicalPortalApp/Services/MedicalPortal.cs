using MedicalPortalApp.Models;

namespace MedicalPortalApp.Services;

public record PortalStatistics(int Patients, int Doctors, int Appointments,
                               int CompletedAppointments, decimal TotalPaid);

/// <summary>Управляет данными портала и основными операциями (задачи 23, 24).</summary>
public class MedicalPortal
{
    private readonly List<Patient> _patients = new();
    private readonly List<Doctor> _doctors = new();
    private readonly List<Department> _departments = new();
    private readonly List<MedicalService> _services = new();
    private readonly List<Appointment> _appointments = new();
    private readonly List<Payment> _payments = new();
    private readonly List<MedicalTest> _tests = new();
    private readonly List<Prescription> _prescriptions = new();

    private int _nextPatientId = 1;
    private int _nextDoctorId = 1;
    private int _nextDepartmentId = 1;
    private int _nextServiceId = 1;
    private int _nextAppointmentId = 1;
    private int _nextPaymentId = 1;
    private int _nextTestId = 1;
    private int _nextPrescriptionId = 1;

    public IReadOnlyList<Patient> Patients => _patients;
    public IReadOnlyList<Doctor> Doctors => _doctors;
    public IReadOnlyList<Department> Departments => _departments;
    public IReadOnlyList<MedicalService> Services => _services;
    public IReadOnlyList<Appointment> Appointments => _appointments;
    public IReadOnlyList<Payment> Payments => _payments;

    // ---------- Добавление ----------

    public Patient AddPatient(string fullName, DateTime birthDate, string phone, string email, string address)
    {
        var patient = new Patient(_nextPatientId, fullName, birthDate, phone, email, address);
        _nextPatientId++;
        _patients.Add(patient);
        return patient;
    }

    public Doctor AddDoctor(string fullName, DateTime birthDate, string specialization,
                            int experience, int cabinet, decimal salary)
    {
        var doctor = new Doctor(_nextDoctorId, fullName, birthDate, specialization, experience, cabinet, salary);
        _nextDoctorId++;
        _doctors.Add(doctor);
        return doctor;
    }

    public Department AddDepartment(string name, int floor, string phone)
    {
        var department = new Department(_nextDepartmentId, name, floor, phone);
        _nextDepartmentId++;
        _departments.Add(department);
        return department;
    }

    public MedicalService AddService(string name, string description, decimal price, int durationMinutes)
    {
        var service = new MedicalService(_nextServiceId, name, description, price, durationMinutes);
        _nextServiceId++;
        _services.Add(service);
        return service;
    }

    // ---------- Поиск по идентификатору ----------

    public Patient? FindPatientById(int id) => _patients.FirstOrDefault(p => p.PatientId == id);
    public Doctor? FindDoctorById(int id) => _doctors.FirstOrDefault(d => d.DoctorId == id);
    public Department? FindDepartmentById(int id) => _departments.FirstOrDefault(d => d.DepartmentId == id);
    public MedicalService? FindServiceById(int id) => _services.FirstOrDefault(s => s.ServiceId == id);
    public Appointment? FindAppointmentById(int id) => _appointments.FirstOrDefault(a => a.AppointmentId == id);
    public Payment? FindPaymentById(int id) => _payments.FirstOrDefault(p => p.PaymentId == id);

    // ---------- Поиск пациентов (задача 23) ----------

    public List<Patient> SearchPatientsByName(string query) =>
        _patients.Where(p => p.FullName.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();

    public List<Patient> SearchPatientsByPhone(string query)
    {
        var digits = new string(query.Where(char.IsDigit).ToArray());
        if (digits.Length == 0) return new List<Patient>();
        return _patients.Where(p => new string(p.PhoneNumber.Where(char.IsDigit).ToArray()).Contains(digits)).ToList();
    }

    // ---------- Приёмы ----------

    public Appointment? TryBookAppointment(Patient patient, Doctor doctor, DateTime date, TimeSpan time, out string? error)
    {
        var appointment = Appointment.TryCreate(_nextAppointmentId, patient, doctor, date, time, out error);
        if (appointment == null) return null;
        _nextAppointmentId++;
        _appointments.Add(appointment);
        return appointment;
    }

    public Appointment? BookAppointment(Patient patient, Doctor doctor, DateTime date, TimeSpan time)
    {
        var appointment = TryBookAppointment(patient, doctor, date, time, out var error);
        if (appointment == null) Console.WriteLine(error);
        return appointment;
    }

    public IEnumerable<Appointment> GetDoctorSchedule(Doctor doctor, DateTime day) =>
        doctor.Appointments
              .Where(a => a.AppointmentDate == day.Date && a.Status != AppointmentStatus.Cancelled)
              .OrderBy(a => a.AppointmentTime);

    // ---------- Анализы и назначения ----------

    public MedicalTest AddMedicalTest(Patient patient, string testName, DateTime testDate, string? result)
    {
        var test = new MedicalTest(_nextTestId, testName, testDate, patient);
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);
        _nextTestId++;
        _tests.Add(test);
        return test;
    }

    public Prescription CreatePrescription(Patient patient, Doctor doctor, string medication,
                                           string dosage, int durationDays)
    {
        var prescription = Prescription.CreatePrescription(_nextPrescriptionId, patient, doctor,
                                                           medication, dosage, durationDays);
        _nextPrescriptionId++;
        _prescriptions.Add(prescription);
        return prescription;
    }

    // ---------- Оплата ----------

    public Payment PayForService(Patient patient, MedicalService service, int quantity, decimal discountPercent = 0)
    {
        decimal amount = service.CalculatePrice(quantity, discountPercent);
        var payment = new Payment(_nextPaymentId, patient, amount, $"{service.ServiceName} × {quantity}");
        _nextPaymentId++;
        payment.MakePayment();
        _payments.Add(payment);
        return payment;
    }

    // ---------- Статистика (задача 24) ----------

    public PortalStatistics GetStatistics() => new(
        _patients.Count,
        _doctors.Count,
        _appointments.Count,
        _appointments.Count(a => a.Status == AppointmentStatus.Completed),
        _payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).Sum(p => p.Amount));

    // ---------- Демонстрационные данные ----------

    public void SeedDemoData()
    {
        var therapy = AddDepartment("Терапия", 1, "+7 7172 00-00-01");
        var cardio = AddDepartment("Кардиология", 2, "+7 7172 00-00-02");

        var ivanov = AddDoctor("Иванов Сергей Петрович", new DateTime(1980, 5, 14), "Терапевт", 15, 101, 300000m);
        var sidorova = AddDoctor("Сидорова Анна Викторовна", new DateTime(1985, 11, 2), "Кардиолог", 10, 205, 350000m);
        therapy.AddDoctor(ivanov);
        therapy.HeadDoctor = ivanov;
        cardio.AddDoctor(sidorova);
        cardio.HeadDoctor = sidorova;

        AddPatient("Петров Алексей Иванович", new DateTime(1992, 3, 21), "+7 701 111 22 33", "petrov@mail.kz", "г. Астана, ул. Абая, 10");
        AddPatient("Ахметова Дана Маратовна", new DateTime(2001, 8, 9), "+7 707 444 55 66", "dana@mail.kz", "г. Астана, пр. Тауелсиздик, 5");

        AddService("Консультация терапевта", "Первичный приём и осмотр", 8000m, 30);
        AddService("ЭКГ", "Электрокардиография", 5000m, 20);
        AddService("Общий анализ крови", "Забор и расшифровка", 3500m, 15);
    }
}
