using System.Text;
using MedicalPortalApp.Services;
using MedicalPortalApp.UI;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

var portal = new MedicalPortal();
portal.SeedDemoData();   // демо-данные, чтобы сразу можно было пользоваться меню

try
{
    new ConsoleMenu(portal).Run();
}
catch (EndOfStreamException)
{
    Console.WriteLine("Ввод завершён. Работа программы остановлена.");
}
